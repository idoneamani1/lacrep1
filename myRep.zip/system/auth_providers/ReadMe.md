This folder contains definitions for auth_providers
