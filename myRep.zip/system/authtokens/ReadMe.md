This contains statically defined API Keys (Auth Tokens) for this project.
Dynamically created keys (using @authentication service) that are still active and not expired valid ARE exported.
