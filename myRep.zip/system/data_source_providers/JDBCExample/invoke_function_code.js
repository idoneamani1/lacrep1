log.info("JDBC Example invoke function code");
//execute a stored procedure or function
