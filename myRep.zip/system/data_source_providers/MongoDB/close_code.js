log.info("Begin MongoDB close code");
connection.client.close();
log.info("End MongoDB close code");
