This folder contains definitions for gateways
