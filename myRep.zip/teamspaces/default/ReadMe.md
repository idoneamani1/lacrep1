This folder contains definitions for teamspace
