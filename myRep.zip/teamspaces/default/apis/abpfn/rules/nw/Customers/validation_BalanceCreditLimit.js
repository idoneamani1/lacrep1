return row.Balance <= row.CreditLimit;
