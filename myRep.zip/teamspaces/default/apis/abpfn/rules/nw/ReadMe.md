Rules for entities in prefix nw
