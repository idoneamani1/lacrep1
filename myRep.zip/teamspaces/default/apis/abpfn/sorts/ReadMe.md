This folder contains definitions for sorts
