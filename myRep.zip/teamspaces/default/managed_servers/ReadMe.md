This folder contains definitions for managed_servers
